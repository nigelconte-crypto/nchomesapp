export default function Documents() {
  return (
    <div style={{padding: '20px'}}>
      <h1>Document Register</h1>
      <p>Strict version control applied. Dummy PDFs listed here.</p>
    </div>
  );
}