export default function Login() {
  return (
    <div style={{padding: '20px'}}>
      <h1>Login</h1>
      <p>Use demo credentials:</p>
      <ul>
        <li>Email: admin@test.com</li>
        <li>Password: password123</li>
      </ul>
    </div>
  );
}