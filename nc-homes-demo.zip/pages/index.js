export default function Home() {
  return (
    <div style={{padding: '20px'}}>
      <h1>NC Homes Dashboard</h1>
      <p>Welcome to the NC Homes Document Management Demo.</p>
    </div>
  );
}