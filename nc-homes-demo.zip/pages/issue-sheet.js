export default function IssueSheet() {
  return (
    <div style={{padding: '20px'}}>
      <h1>Issue Sheet</h1>
      <p>Generate and track issue sheets for documents.</p>
    </div>
  );
}